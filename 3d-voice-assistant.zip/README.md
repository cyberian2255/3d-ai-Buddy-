# 3D Voice Assistant

Next.js app with a 3D voice buddy. Chat goes through `/api/chat`, which uses OpenRouter.

## Run locally
```bash
cp .env.example .env.local   # add your OPENROUTER_API_KEY
pnpm install
pnpm dev
```

## GitHub
CI (`.github/workflows/ci.yml`) installs and builds on every push and PR to `main`.
Optional repo secret: `OPENROUTER_API_KEY` (Settings > Secrets and variables > Actions).

## Deploy
The app has a server API route, so it can't run on GitHub Pages. Import the repo on
Vercel and add `OPENROUTER_API_KEY` as an environment variable.
