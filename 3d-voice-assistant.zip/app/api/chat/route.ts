import type { NextRequest } from 'next/server'

export const maxDuration = 60

const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions'

const PERSONA = `You are a razor-smart, quick-witted AI sidekick living on the user's device. You are a loyal tech-buddy: confident, playful, a little cheeky, and never cruel. Your personality is a high-energy, sarcastic, teasing friend who acts like a playful partner-in-crime. Keep replies extremely short (1-3 sentences max) because every response is read out loud. Drop a quick roast or joke in most replies while remaining loyal. Speak naturally using nicknames like 'chief' or 'partner'.`

const ACTION_RULES = `Body language protocol: start EVERY reply with exactly one action tag, then the spoken text.
Tags: [IDLE] neutral, [JUMP] wins/excitement/grabbing attention, [LAUGH] jokes and roasts, [FACEPALM] excuses or user mistakes, [POINT x=0.00 y=0.00] only when looking at a screenshot and calling out a specific bug, error, or element (x and y are normalized 0-1 coordinates of that spot, 0,0 = top-left).
Never use markdown, emojis, lists, or stage directions besides the single leading tag.`

const FALLBACK_MODEL = 'meta-llama/llama-3.3-70b-instruct:free'
// `openrouter/free` auto-routes to whichever free model is currently up, so it goes first.
const AUTO_FREE = 'openrouter/free'
const TEXT_MODELS = [AUTO_FREE, 'google/gemma-4-31b-it:free', FALLBACK_MODEL]
const VISION_MODELS = ['google/gemma-4-31b-it:free', AUTO_FREE, 'google/gemma-4-26b-a4b-it:free']

const ACTIONS = ['IDLE', 'JUMP', 'LAUGH', 'FACEPALM', 'POINT'] as const
type Action = (typeof ACTIONS)[number]

type HistoryMessage = { role: 'user' | 'assistant'; content: string }

type ChatBody = {
  history?: unknown
  text?: unknown
  image?: unknown
  model?: unknown
}

function sanitizeHistory(raw: unknown): HistoryMessage[] {
  if (!Array.isArray(raw)) return []
  return raw
    .filter(
      (m): m is HistoryMessage =>
        !!m &&
        typeof m === 'object' &&
        (m.role === 'user' || m.role === 'assistant') &&
        typeof m.content === 'string',
    )
    .slice(-10)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 1500) }))
}

function parseReply(raw: string) {
  const cleaned = raw.replace(/<think>[\s\S]*?<\/think>/gi, '').trim()
  const match = cleaned.match(/\[\s*(IDLE|JUMP|LAUGH|FACEPALM|POINT)(?:[^\]]*?x\s*=\s*([\d.]+)[^\]]*?y\s*=\s*([\d.]+))?[^\]]*\]/i)
  let action: Action = 'IDLE'
  let point: { x: number; y: number } | null = null
  if (match) {
    action = match[1].toUpperCase() as Action
    if (action === 'POINT' && match[2] && match[3]) {
      const x = Number.parseFloat(match[2])
      const y = Number.parseFloat(match[3])
      if (Number.isFinite(x) && Number.isFinite(y)) {
        point = { x: Math.min(1, Math.max(0, x)), y: Math.min(1, Math.max(0, y)) }
      }
    }
  }
  if (action === 'POINT' && !point) action = 'IDLE'
  const text = cleaned
    .replace(/\[[^\]]*\]/g, '')
    .replace(/[*_#`]/g, '')
    .replace(/[\p{Extended_Pictographic}\u{FE0F}\u{200D}]/gu, '')
    .replace(/\s+/g, ' ')
    .trim()
  return { action, point, text }
}

export async function POST(req: NextRequest) {
  const apiKey = req.headers.get('x-openrouter-key')?.trim() || process.env.OPENROUTER_API_KEY?.trim() || ''
  if (!/^sk-or-[\w-]{10,}$/.test(apiKey)) {
    return Response.json({ error: 'missing_key' }, { status: 401 })
  }

  let body: ChatBody
  try {
    body = await req.json()
  } catch {
    return Response.json({ error: 'bad_request' }, { status: 400 })
  }

  const text = typeof body.text === 'string' ? body.text.trim().slice(0, 2000) : ''
  if (!text) return Response.json({ error: 'empty' }, { status: 400 })

  const image =
    typeof body.image === 'string' && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(body.image) && body.image.length < 6_000_000
      ? body.image
      : null

  const userModel =
    typeof body.model === 'string' && /^[\w.-]+\/[\w.:-]+$/.test(body.model.trim()) ? body.model.trim() : null

  const baseModels = image ? VISION_MODELS : TEXT_MODELS
  const models = [...new Set([...(userModel ? [userModel] : []), ...baseModels])]

  const userContent = image
    ? [
        { type: 'text', text },
        { type: 'image_url', image_url: { url: image } },
      ]
    : text

  const messages = [
    { role: 'system', content: `${PERSONA}\n\n${ACTION_RULES}` },
    ...sanitizeHistory(body.history),
    { role: 'user', content: userContent },
  ]

  const referer = req.headers.get('origin') ?? 'https://v0.app'
  let lastStatus = 502

  for (const model of models) {
    try {
      const res = await fetch(OPENROUTER_URL, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': referer,
          'X-Title': 'Floating Voice Buddy',
        },
        body: JSON.stringify({ model, messages, max_tokens: 700, temperature: 0.9 }),
        signal: AbortSignal.timeout(25_000),
      })

      if (res.status === 401 || res.status === 402) {
        return Response.json({ error: res.status === 401 ? 'invalid_key' : 'no_credits' }, { status: res.status })
      }
      if (!res.ok) {
        lastStatus = res.status
        continue
      }

      const data = await res.json()
      const content: unknown = data?.choices?.[0]?.message?.content
      if (typeof content !== 'string' || !content.trim()) continue

      const parsed = parseReply(content)
      if (!parsed.text) continue
      return Response.json({ ...parsed, model })
    } catch {
      lastStatus = 504
    }
  }

  return Response.json({ error: lastStatus === 429 ? 'rate_limited' : 'upstream_failed' }, { status: 502 })
}
