import { VoiceBuddy } from '@/components/buddy/voice-buddy'

export default function Page() {
  return <VoiceBuddy />
}
