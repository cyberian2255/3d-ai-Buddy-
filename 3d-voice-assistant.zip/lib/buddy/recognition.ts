type RecognitionResultEvent = {
  resultIndex: number
  results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }>
}

type RecognitionInstance = {
  lang: string
  continuous: boolean
  interimResults: boolean
  maxAlternatives: number
  start: () => void
  stop: () => void
  abort: () => void
  onresult: ((e: RecognitionResultEvent) => void) | null
  onerror: ((e: { error: string }) => void) | null
  onend: (() => void) | null
  onspeechstart: (() => void) | null
}

type RecognitionCtor = new () => RecognitionInstance

function getCtor(): RecognitionCtor | null {
  if (typeof window === 'undefined') return null
  const w = window as unknown as { SpeechRecognition?: RecognitionCtor; webkitSpeechRecognition?: RecognitionCtor }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

export function isRecognitionSupported() {
  return getCtor() !== null
}

type Handlers = {
  onSpeech: () => void
  onInterim: (text: string) => void
  onFinal: (text: string) => void
  onError: (error: string) => void
  onEnd: () => void
}

export function startRecognition(handlers: Handlers) {
  const Ctor = getCtor()
  if (!Ctor) return null

  const rec = new Ctor()
  rec.lang = navigator.language || 'en-US'
  rec.continuous = false
  rec.interimResults = true
  rec.maxAlternatives = 1

  let delivered = false
  rec.onspeechstart = handlers.onSpeech
  rec.onresult = (e) => {
    let interim = ''
    let final = ''
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i]
      if (r.isFinal) final += r[0].transcript
      else interim += r[0].transcript
    }
    if (interim) handlers.onInterim(interim)
    if (final.trim() && !delivered) {
      delivered = true
      handlers.onFinal(final.trim())
    }
  }
  rec.onerror = (e) => handlers.onError(e.error)
  rec.onend = handlers.onEnd

  try {
    rec.start()
  } catch {
    return null
  }
  return rec
}
