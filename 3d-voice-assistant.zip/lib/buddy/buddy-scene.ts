import * as THREE from 'three'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'

export type OneShot = 'jump' | 'laugh' | 'facepalm' | 'point'
export type BaseState = 'idle' | 'listening' | 'thinking'

type Pose = {
  rootY: number
  rootRotY: number
  rootRotZ: number
  bodyRotX: number
  bodyScaleY: number
  headRotX: number
  headRotY: number
  headRotZ: number
  armLx: number
  armLz: number
  armRx: number
  armRz: number
  legLx: number
  legRx: number
  eyeOpen: number
  eyeSquint: number
  eyeLookY: number
  mouthOpen: number
}

const REST: Pose = {
  rootY: 0,
  rootRotY: 0,
  rootRotZ: 0,
  bodyRotX: 0,
  bodyScaleY: 1,
  headRotX: 0,
  headRotY: 0,
  headRotZ: 0,
  armLx: 0,
  armLz: -0.12,
  armRx: 0,
  armRz: 0.12,
  legLx: 0,
  legRx: 0,
  eyeOpen: 1,
  eyeSquint: 0,
  eyeLookY: 0,
  mouthOpen: 0,
}

const ONE_SHOT_DURATION: Record<OneShot, number> = {
  jump: 1.0,
  laugh: 1.9,
  facepalm: 2.2,
  point: 2.8,
}

const COLORS = {
  shell: 0xf2f4ff,
  accent: 0x5b6cff,
  violet: 0xa35bff,
  visor: 0x0a0f24,
  glow: 0x7fe7ff,
}

const auraVertex = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`

const auraFragment = /* glsl */ `
  uniform float uTime;
  uniform float uIntensity;
  uniform float uSpin;
  varying vec2 vUv;
  void main() {
    vec2 p = vUv - 0.5;
    float r = length(p) * 2.0;
    float a = atan(p.y, p.x) + uSpin;
    vec3 c1 = vec3(0.36, 0.42, 1.0);
    vec3 c2 = vec3(0.64, 0.36, 1.0);
    vec3 c3 = vec3(0.50, 0.91, 1.0);
    float t = 0.5 + 0.5 * sin(a);
    float u = 0.5 + 0.5 * sin(a * 2.0 + 1.7);
    vec3 col = mix(mix(c1, c2, t), c3, u * 0.6);
    float pulse = 0.5 + 0.5 * sin(uTime * 4.0);
    float ringR = 0.78 + pulse * 0.04;
    float ring = exp(-pow((r - ringR) / 0.045, 2.0));
    float halo = exp(-pow((r - ringR) / 0.18, 2.0)) * 0.45;
    float inner = smoothstep(0.85, 0.0, r) * 0.12;
    float alpha = (ring + halo + inner) * uIntensity;
    gl_FragColor = vec4(col * alpha, alpha);
  }
`

function makeZTexture() {
  const c = document.createElement('canvas')
  c.width = 64
  c.height = 64
  const ctx = c.getContext('2d')
  if (ctx) {
    ctx.fillStyle = '#c9d4ff'
    ctx.font = 'bold 52px system-ui, sans-serif'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText('Z', 32, 34)
  }
  const tex = new THREE.CanvasTexture(c)
  tex.colorSpace = THREE.SRGBColorSpace
  return tex
}

export class BuddyScene {
  onTick?: (dt: number) => void

  private renderer: THREE.WebGLRenderer
  private scene = new THREE.Scene()
  private camera: THREE.PerspectiveCamera
  private clock = new THREE.Clock()
  private raf = 0
  private disposed = false

  private root = new THREE.Group()
  private body = new THREE.Group()
  private head = new THREE.Group()
  private armL = new THREE.Group()
  private armR = new THREE.Group()
  private legL = new THREE.Group()
  private legR = new THREE.Group()
  private eyes: THREE.Mesh[] = []
  private mouth!: THREE.Mesh
  private chestLight!: THREE.Mesh
  private antennaTip!: THREE.Mesh
  private shadow!: THREE.Mesh
  private aura!: THREE.Mesh<THREE.PlaneGeometry, THREE.ShaderMaterial>
  private zs: THREE.Sprite[] = []

  private pose: Pose = { ...REST }
  private base: BaseState = 'idle'
  private speaking = false
  private speechPulse = 0
  private walking = false
  private walkDir = 0
  private grabbed = false
  private sleeping = false
  private sleepStart = 0
  private oneShot: { type: OneShot; start: number; dir: number } | null = null
  private nextBlink = 2
  private auraIntensity = 0
  private auraSpin = 0

  constructor(private canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true })
    this.renderer.setClearColor(0x000000, 0)
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    this.renderer.outputColorSpace = THREE.SRGBColorSpace
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping
    this.renderer.toneMappingExposure = 1.05

    this.camera = new THREE.PerspectiveCamera(30, 1, 0.1, 50)
    this.camera.position.set(0, 1.35, 8.2)
    this.camera.lookAt(0, 1.3, 0)

    const pmrem = new THREE.PMREMGenerator(this.renderer)
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture
    pmrem.dispose()

    this.scene.add(new THREE.HemisphereLight(0xffffff, COLORS.accent, 0.9))
    const key = new THREE.DirectionalLight(0xffffff, 1.8)
    key.position.set(2, 4, 5)
    this.scene.add(key)
    const rim = new THREE.DirectionalLight(COLORS.violet, 2.2)
    rim.position.set(-3, 2.5, -3)
    this.scene.add(rim)

    this.buildCharacter()
    this.scene.add(this.root)
    this.resize()
    this.loop()
  }

  private buildCharacter() {
    const shell = new THREE.MeshPhysicalMaterial({
      color: COLORS.shell,
      roughness: 0.28,
      metalness: 0.05,
      clearcoat: 1,
      clearcoatRoughness: 0.12,
    })
    const accent = new THREE.MeshPhysicalMaterial({ color: COLORS.accent, roughness: 0.3, metalness: 0.2, clearcoat: 0.6 })
    const visor = new THREE.MeshPhysicalMaterial({ color: COLORS.visor, roughness: 0.22, metalness: 0.3, clearcoat: 0.6, envMapIntensity: 0.35 })
    const glow = new THREE.MeshBasicMaterial({ color: COLORS.glow, toneMapped: false })
    const violetGlow = new THREE.MeshBasicMaterial({ color: COLORS.violet, toneMapped: false })

    // Aura plane behind the character.
    this.aura = new THREE.Mesh(
      new THREE.PlaneGeometry(3.8, 3.8),
      new THREE.ShaderMaterial({
        vertexShader: auraVertex,
        fragmentShader: auraFragment,
        uniforms: { uTime: { value: 0 }, uIntensity: { value: 0 }, uSpin: { value: 0 } },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    )
    this.aura.position.set(0, 1.35, -0.9)
    this.aura.renderOrder = -1
    this.scene.add(this.aura)

    this.shadow = new THREE.Mesh(
      new THREE.CircleGeometry(0.55, 32),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28, depthWrite: false }),
    )
    this.shadow.rotation.x = -Math.PI / 2
    this.shadow.position.y = 0.01
    this.shadow.scale.set(1, 0.6, 1)
    this.scene.add(this.shadow)

    // Legs
    const legGeo = new THREE.CapsuleGeometry(0.11, 0.36, 6, 14)
    const footGeo = new THREE.SphereGeometry(0.15, 20, 14)
    for (const [leg, x] of [
      [this.legL, -0.19],
      [this.legR, 0.19],
    ] as const) {
      leg.position.set(x, 0.78, 0)
      const limb = new THREE.Mesh(legGeo, shell)
      limb.position.y = -0.3
      const foot = new THREE.Mesh(footGeo, accent)
      foot.scale.set(1, 0.6, 1.4)
      foot.position.set(0, -0.66, 0.06)
      leg.add(limb, foot)
      this.root.add(leg)
    }

    // Body
    this.body.position.y = 0.75
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.42, 0.22, 10, 24), shell)
    torso.position.y = 0.42
    this.chestLight = new THREE.Mesh(new THREE.CircleGeometry(0.09, 24), violetGlow.clone())
    this.chestLight.position.set(0, 0.46, 0.425)
    const belt = new THREE.Mesh(new THREE.TorusGeometry(0.41, 0.035, 10, 40), accent)
    belt.rotation.x = Math.PI / 2
    belt.position.y = 0.2
    this.body.add(torso, this.chestLight, belt)

    // Arms
    const armGeo = new THREE.CapsuleGeometry(0.095, 0.3, 6, 14)
    const handGeo = new THREE.SphereGeometry(0.125, 20, 14)
    for (const [arm, x] of [
      [this.armL, -0.47],
      [this.armR, 0.47],
    ] as const) {
      arm.position.set(x, 0.66, 0)
      const limb = new THREE.Mesh(armGeo, shell)
      limb.position.y = -0.26
      const hand = new THREE.Mesh(handGeo, accent)
      hand.position.y = -0.52
      arm.add(limb, hand)
      this.body.add(arm)
    }

    // Head
    this.head.position.y = 0.86
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.54, 40, 28), shell)
    skull.scale.set(1.1, 0.94, 1)
    skull.position.y = 0.46
    const face = new THREE.Mesh(new THREE.SphereGeometry(0.5, 40, 28), visor)
    face.scale.set(0.86, 0.64, 0.62)
    face.position.set(0, 0.46, 0.26)

    const eyeGeo = new THREE.CapsuleGeometry(0.062, 0.09, 6, 14)
    for (const x of [-0.17, 0.17]) {
      const eye = new THREE.Mesh(eyeGeo, glow)
      eye.position.set(x, 0.52, 0.57)
      this.eyes.push(eye)
      this.head.add(eye)
    }
    this.mouth = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.12, 6, 12), glow)
    this.mouth.rotation.z = Math.PI / 2
    this.mouth.position.set(0, 0.34, 0.55)

    const earGeo = new THREE.CylinderGeometry(0.13, 0.13, 0.1, 24)
    for (const x of [-0.6, 0.6]) {
      const ear = new THREE.Mesh(earGeo, accent)
      ear.rotation.z = Math.PI / 2
      ear.position.set(x, 0.46, 0)
      this.head.add(ear)
    }
    const stalk = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.22, 8), accent)
    stalk.position.y = 1.02
    this.antennaTip = new THREE.Mesh(new THREE.SphereGeometry(0.065, 16, 12), violetGlow.clone())
    this.antennaTip.position.y = 1.15

    this.head.add(skull, face, this.mouth, stalk, this.antennaTip)
    this.body.add(this.head)
    this.root.add(this.body)

    const zTex = makeZTexture()
    for (let i = 0; i < 3; i++) {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: zTex, transparent: true, depthWrite: false }))
      s.visible = false
      this.zs.push(s)
      this.scene.add(s)
    }
  }

  setBase(state: BaseState) {
    this.base = state
  }

  setSpeaking(on: boolean) {
    this.speaking = on
  }

  pulseSpeech() {
    this.speechPulse = 1
  }

  setWalking(on: boolean, dir = 0) {
    this.walking = on
    this.walkDir = dir
  }

  setGrabbed(on: boolean) {
    this.grabbed = on
  }

  setSleeping(on: boolean) {
    if (on === this.sleeping) return
    this.sleeping = on
    this.sleepStart = this.clock.elapsedTime
  }

  play(type: OneShot, dir = 1) {
    this.oneShot = { type, start: this.clock.elapsedTime, dir }
  }

  resize() {
    const { clientWidth: w, clientHeight: h } = this.canvas
    if (!w || !h) return
    this.renderer.setSize(w, h, false)
    this.camera.aspect = w / h
    this.camera.updateProjectionMatrix()
  }

  dispose() {
    this.disposed = true
    cancelAnimationFrame(this.raf)
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh
      mesh.geometry?.dispose()
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose())
      else mat?.dispose()
    })
    this.renderer.dispose()
  }

  private loop = () => {
    if (this.disposed) return
    this.raf = requestAnimationFrame(this.loop)
    const dt = Math.min(this.clock.getDelta(), 0.05)
    const t = this.clock.elapsedTime
    this.onTick?.(dt)
    this.animate(dt, t)
    this.renderer.render(this.scene, this.camera)
  }

  private target(t: number): Pose {
    const p: Pose = { ...REST }
    const breath = Math.sin(t * 2.2)

    p.bodyScaleY = 1 + breath * 0.018
    p.headRotX = Math.sin(t * 1.1) * 0.04
    p.headRotZ = Math.sin(t * 0.7) * 0.05
    p.armLz = -0.12 - breath * 0.035
    p.armRz = 0.12 + breath * 0.035

    if (t > this.nextBlink) {
      if (t > this.nextBlink + 0.13) this.nextBlink = t + 2.5 + Math.random() * 3
      else p.eyeOpen = 0.1
    }

    if (this.sleeping) {
      const since = t - this.sleepStart
      p.rootY = -0.42
      p.legLx = -1.45
      p.legRx = -1.45
      p.armLx = -0.45
      p.armRx = -0.45
      p.armLz = -0.05
      p.armRz = 0.05
      if (since > 2.2) {
        const slowBreath = Math.sin(t * 1.3)
        p.bodyScaleY = 1 + slowBreath * 0.03
        p.bodyRotX = 0.22
        p.headRotX = 0.45 + slowBreath * 0.03
        p.headRotZ = 0.25
        p.armLz = -0.28
        p.armRz = 0.28
        p.eyeOpen = 0.06
      } else {
        p.eyeOpen = since > 1.2 ? 0.35 : 0.8
        p.headRotX = 0.12
      }
    } else if (this.base === 'listening') {
      p.headRotZ = 0.18 + Math.sin(t * 1.4) * 0.03
      p.headRotX = -0.04
      p.bodyRotX = 0.06
      p.eyeOpen = Math.min(p.eyeOpen, 1) * 1.18
      p.armLz = -0.3
      p.armRz = 0.3
    } else if (this.base === 'thinking') {
      p.armRx = -2.05
      p.armRz = -0.55
      p.headRotX = -0.16
      p.headRotY = 0.18
      p.eyeLookY = 0.04
      p.headRotZ = Math.sin(t * 2) * 0.05
    }

    if (this.speaking && !this.sleeping) {
      p.headRotX += Math.sin(t * 6) * 0.045
      p.armLx += Math.sin(t * 2.6) * 0.22 - 0.15
      p.armRx += this.base === 'thinking' ? 0 : Math.sin(t * 2.6 + 1.4) * 0.22 - 0.15
      const chatter = Math.abs(Math.sin(t * 13)) * Math.abs(Math.sin(t * 7.3))
      p.mouthOpen = 0.2 + chatter * 0.55 + this.speechPulse * 0.35
    }

    if (this.walking && !this.sleeping) {
      const s = Math.sin(t * 9)
      p.legLx = s * 0.6
      p.legRx = -s * 0.6
      p.armLx = -s * 0.5
      p.armRx = s * 0.5
      p.rootY = Math.abs(Math.cos(t * 9)) * 0.07
      p.rootRotY = this.walkDir * 1.15
      p.bodyRotX = 0.08
    }

    if (this.grabbed) {
      p.legLx = Math.sin(t * 7) * 0.5
      p.legRx = -Math.sin(t * 7) * 0.5
      p.armLz = -2.4
      p.armRz = 2.4
      p.eyeOpen = 1.25
      p.mouthOpen = 0.5
      p.rootRotZ = Math.sin(t * 3) * 0.12
    }

    if (this.oneShot) {
      const { type, start, dir } = this.oneShot
      const elapsed = t - start
      const u = elapsed / ONE_SHOT_DURATION[type]
      if (u >= 1) {
        this.oneShot = null
      } else if (type === 'jump') {
        if (u < 0.18) {
          p.rootY = -0.12 * (u / 0.18)
          p.bodyRotX = 0.15
          p.legLx = -0.25
          p.legRx = -0.25
        } else if (u < 0.8) {
          const a = (u - 0.18) / 0.62
          p.rootY = Math.sin(a * Math.PI) * 0.62
          p.armLz = -2.7
          p.armRz = 2.7
          p.legLx = -0.4
          p.legRx = 0.3
          p.eyeSquint = 1
          p.mouthOpen = Math.max(p.mouthOpen, 0.6)
        } else {
          p.rootY = -0.08 * (1 - (u - 0.8) / 0.2)
        }
      } else if (type === 'laugh') {
        p.rootRotZ = Math.sin(t * 28) * 0.06
        p.rootY = Math.abs(Math.sin(t * 14)) * 0.07
        p.headRotX = -0.35
        p.bodyRotX = -0.1
        p.armLx = -0.75
        p.armLz = 0.35
        p.armRx = -0.75
        p.armRz = -0.35
        p.eyeSquint = 1
        p.mouthOpen = 0.85 + Math.sin(t * 28) * 0.2
      } else if (type === 'facepalm') {
        p.armLx = -2.55
        p.armLz = 0.7
        p.armRz = 0.2
        p.headRotX = 0.18
        p.headRotZ = -0.12
        p.bodyRotX = 0.14
        p.eyeOpen = 0.12
        p.headRotY = Math.sin(t * 5) * 0.08
      } else if (type === 'point') {
        if (dir > 0) {
          p.armRz = 1.45
          p.armRx = -0.35
        } else {
          p.armLz = -1.45
          p.armLx = -0.35
        }
        p.headRotY = dir * 0.25
        p.rootRotY = dir * 0.35
        p.rootY = Math.abs(Math.sin(t * 6)) * 0.03
        p.eyeOpen = Math.max(p.eyeOpen, 1.1)
      }
    }

    return p
  }

  private animate(dt: number, t: number) {
    const target = this.target(t)
    const k = 1 - Math.exp(-dt * 11)
    const kFast = 1 - Math.exp(-dt * 20)
    const pose = this.pose
    for (const key of Object.keys(target) as (keyof Pose)[]) {
      const rate = key === 'rootY' || key === 'mouthOpen' || key === 'eyeOpen' ? kFast : k
      pose[key] += (target[key] - pose[key]) * rate
    }
    this.speechPulse = Math.max(0, this.speechPulse - dt * 4)

    this.root.position.y = pose.rootY
    this.root.rotation.set(0, pose.rootRotY, pose.rootRotZ)
    this.body.rotation.x = pose.bodyRotX
    this.body.scale.set(1, pose.bodyScaleY, 1)
    this.head.rotation.set(pose.headRotX, pose.headRotY, pose.headRotZ)
    this.armL.rotation.set(pose.armLx, 0, pose.armLz)
    this.armR.rotation.set(pose.armRx, 0, pose.armRz)
    this.legL.rotation.x = pose.legLx
    this.legR.rotation.x = pose.legRx

    const eyeY = Math.max(0.05, pose.eyeOpen * (1 - pose.eyeSquint * 0.6))
    for (const eye of this.eyes) {
      eye.scale.set(1, eyeY, 1)
      eye.position.y = 0.52 + pose.eyeLookY + pose.eyeSquint * 0.02
    }
    const mouth = Math.max(0, pose.mouthOpen)
    this.mouth.scale.set(1 + mouth * 3.2, 1 - mouth * 0.2, 1)

    const lift = Math.max(0, pose.rootY)
    this.shadow.scale.set(1 - lift * 0.6, 0.6 - lift * 0.35, 1)
    ;(this.shadow.material as THREE.MeshBasicMaterial).opacity = 0.28 - lift * 0.2

    const listening = this.base === 'listening' && !this.sleeping
    const thinking = this.base === 'thinking'
    const auraTarget = this.sleeping ? 0 : listening ? 1 : thinking ? 0.75 : this.speaking ? 0.5 : 0.12
    this.auraIntensity += (auraTarget - this.auraIntensity) * (1 - Math.exp(-dt * 5))
    this.auraSpin += dt * (thinking ? 4 : listening ? 1.2 : 0.4)
    const uniforms = this.aura.material.uniforms
    uniforms.uTime.value = t
    uniforms.uIntensity.value = this.auraIntensity * (listening ? 0.8 + Math.sin(t * 4) * 0.2 : 1)
    uniforms.uSpin.value = this.auraSpin
    this.aura.position.y = 1.35 + pose.rootY * 0.6
    const auraScale = 1 + (listening ? Math.sin(t * 4) * 0.04 : 0)
    this.aura.scale.setScalar(auraScale)

    const glowLevel = listening ? 0.7 + Math.sin(t * 6) * 0.3 : this.speaking ? 0.6 + mouth * 0.4 : 0.55
    ;(this.chestLight.material as THREE.MeshBasicMaterial).color.setHex(listening ? COLORS.glow : COLORS.violet).multiplyScalar(glowLevel + 0.45)
    ;(this.antennaTip.material as THREE.MeshBasicMaterial).color
      .setHex(thinking ? COLORS.glow : COLORS.violet)
      .multiplyScalar(thinking ? 0.7 + Math.abs(Math.sin(t * 8)) * 0.6 : 1)

    const showZ = this.sleeping && t - this.sleepStart > 2.2
    this.zs.forEach((s, i) => {
      s.visible = showZ
      if (!showZ) return
      const phase = (t * 0.45 + i / 3) % 1
      s.position.set(0.45 + phase * 0.55, 1.75 + phase * 1.0, 0.3)
      s.scale.setScalar(0.22 + phase * 0.22)
      s.material.opacity = Math.sin(phase * Math.PI)
    })
  }
}
