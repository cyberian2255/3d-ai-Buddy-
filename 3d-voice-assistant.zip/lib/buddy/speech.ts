const VOICE_PREFERENCES: RegExp[] = [
  /GuyNeural|Microsoft Guy\b.*Natural/i,
  /ChristopherNeural|Microsoft Christopher\b.*Natural/i,
  /Microsoft (Andrew|Brian|Eric|Roger|Steffan)\w*\b.*Natural.*English/i,
  /Natural.*English.*Male|English.*Natural.*Male/i,
  /Microsoft.*Online.*Natural.*English \(United States\)/i,
  /Microsoft.*Natural.*English/i,
  /Natural.*English/i,
  /Google UK English Male/i,
  /Microsoft (David|Mark)\b/i,
  /Daniel|Alex|Fred/i,
]

const START_TIMEOUT_MS = 5000

let cachedVoice: SpeechSynthesisVoice | null = null
let failedVoiceNames = new Set<string>()
let primed = false
let voicesListenerAdded = false

function isNatural(v: SpeechSynthesisVoice) {
  return /Natural|Neural/i.test(v.name)
}

export function pickVoice(): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !window.speechSynthesis) return null
  if (cachedVoice && !failedVoiceNames.has(cachedVoice.name)) return cachedVoice
  const voices = window.speechSynthesis
    .getVoices()
    .filter((v) => v.lang.toLowerCase().startsWith('en') && !failedVoiceNames.has(v.name))
  if (!voices.length) return null
  for (const pattern of VOICE_PREFERENCES) {
    const match = voices.find((v) => pattern.test(v.name))
    if (match) {
      cachedVoice = match
      return match
    }
  }
  cachedVoice = voices.find((v) => v.lang.toLowerCase().startsWith('en-us')) ?? voices[0] ?? null
  return cachedVoice
}

export function initVoices() {
  if (typeof window === 'undefined' || !window.speechSynthesis) return
  pickVoice()
  if (voicesListenerAdded) return
  voicesListenerAdded = true
  // Edge loads its online Natural voices after the local ones, so re-pick when they arrive.
  window.speechSynthesis.addEventListener('voiceschanged', () => {
    cachedVoice = null
    pickVoice()
  })
}

/** Browsers only allow synthesis after a user gesture has spoken at least once. */
export function primeSpeech() {
  if (primed || typeof window === 'undefined' || !window.speechSynthesis) return
  primed = true
  const u = new SpeechSynthesisUtterance(' ')
  u.volume = 0
  window.speechSynthesis.speak(u)
}

type SpeakHandlers = {
  onStart?: () => void
  onBoundary?: () => void
  onEnd?: () => void
}

export function speak(text: string, handlers: SpeakHandlers = {}) {
  const synth = typeof window !== 'undefined' ? window.speechSynthesis : undefined
  if (!synth || !text.trim()) {
    handlers.onEnd?.()
    return () => {}
  }

  let finished = false
  let cancelled = false
  let startTimer: ReturnType<typeof setTimeout> | undefined
  let endTimer: ReturnType<typeof setTimeout> | undefined
  let kickTimer: ReturnType<typeof setTimeout> | undefined
  let resumeTimer: ReturnType<typeof setInterval> | undefined

  const finish = () => {
    if (finished) return
    finished = true
    clearTimeout(startTimer)
    clearTimeout(endTimer)
    clearTimeout(kickTimer)
    clearInterval(resumeTimer)
    handlers.onEnd?.()
  }

  const attempt = (isRetry: boolean) => {
    if (cancelled || finished) return
    const utterance = new SpeechSynthesisUtterance(text)
    const voice = pickVoice()
    if (voice) {
      utterance.voice = voice
      utterance.lang = voice.lang
    } else {
      utterance.lang = 'en-US'
    }
    utterance.rate = 1.1
    utterance.pitch = 0.95
    let started = false

    utterance.onstart = () => {
      started = true
      clearTimeout(startTimer)
      // Safety net only once audio actually started; Natural voices can take a moment to buffer.
      const estimatedMs = text.split(/\s+/).length * 450 + 4000
      endTimer = setTimeout(finish, estimatedMs)
      handlers.onStart?.()
    }
    utterance.onboundary = () => handlers.onBoundary?.()
    utterance.onend = finish
    utterance.onerror = (e) => {
      if (cancelled || e.error === 'interrupted' || e.error === 'canceled') return finish()
      if (!started && !isRetry && voice) {
        failedVoiceNames.add(voice.name)
        cachedVoice = null
        attempt(true)
        return
      }
      finish()
    }

    // If an online Natural voice never starts (offline / blocked), fall back to a local voice.
    startTimer = setTimeout(() => {
      if (started || finished || cancelled) return
      if (!isRetry && voice && isNatural(voice)) {
        synth.cancel()
        failedVoiceNames.add(voice.name)
        cachedVoice = null
        kickTimer = setTimeout(() => attempt(true), 80)
      } else {
        finish()
      }
    }, START_TIMEOUT_MS)

    synth.speak(utterance)
  }

  // Edge silently drops an utterance queued in the same tick as cancel().
  const wasBusy = synth.speaking || synth.pending
  synth.cancel()
  if (synth.paused) synth.resume()
  kickTimer = setTimeout(() => attempt(false), wasBusy ? 120 : 30)

  // Chromium can pause long utterances; nudge it while speaking.
  resumeTimer = setInterval(() => {
    if (synth.speaking && synth.paused) synth.resume()
  }, 3000)

  return () => {
    cancelled = true
    synth.cancel()
    finish()
  }
}

export function resetVoiceFailures() {
  failedVoiceNames = new Set()
  cachedVoice = null
}
