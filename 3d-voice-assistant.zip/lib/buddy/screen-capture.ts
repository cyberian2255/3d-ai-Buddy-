export async function captureScreenFrame(maxWidth = 1280): Promise<string> {
  if (!navigator.mediaDevices?.getDisplayMedia) {
    throw new Error('unsupported')
  }
  const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false })
  try {
    const video = document.createElement('video')
    video.srcObject = stream
    video.muted = true
    video.playsInline = true
    await video.play()
    await new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))

    const width = video.videoWidth
    const height = video.videoHeight
    if (!width || !height) throw new Error('no_frame')

    const scale = Math.min(1, maxWidth / width)
    const canvas = document.createElement('canvas')
    canvas.width = Math.round(width * scale)
    canvas.height = Math.round(height * scale)
    const ctx = canvas.getContext('2d')
    if (!ctx) throw new Error('no_context')
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
    video.srcObject = null
    return canvas.toDataURL('image/jpeg', 0.72)
  } finally {
    stream.getTracks().forEach((t) => t.stop())
  }
}
