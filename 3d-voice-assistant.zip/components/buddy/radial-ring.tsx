'use client'

import { Mic, MicOff, ScanEye } from 'lucide-react'
import { cn } from '@/lib/utils'

type RadialRingProps = {
  open: boolean
  micOn: boolean
  busy: boolean
  onVision: () => void
  onMic: () => void
}

const buttonBase =
  'absolute flex size-11 items-center justify-center rounded-full border text-white shadow-[0_0_24px_-4px_rgba(91,108,255,0.7)] backdrop-blur-md transition-all duration-300 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 disabled:opacity-50'

export function RadialRing({ open, micOn, busy, onVision, onMic }: RadialRingProps) {
  return (
    <div className="pointer-events-none absolute inset-0" aria-hidden={!open}>
      <div
        className={cn(
          'absolute left-1/2 top-[46%] size-[176px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/15 transition-all duration-300 ease-out',
          open ? 'scale-100 opacity-100' : 'scale-75 opacity-0',
        )}
      />
      <button
        type="button"
        aria-label="Screen vision: let the buddy look at your screen"
        title="Screen vision"
        disabled={busy}
        tabIndex={open ? 0 : -1}
        onPointerDown={(e) => e.stopPropagation()}
        onClick={onVision}
        className={cn(
          buttonBase,
          'left-[6px] top-[38px] border-white/20 bg-[#0d1230]/80 hover:bg-[#1a2150]/90',
          open ? 'pointer-events-auto translate-x-0 translate-y-0 scale-100 opacity-100' : 'translate-x-10 translate-y-8 scale-50 opacity-0',
        )}
      >
        <ScanEye className="size-5" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label={micOn ? 'Mute microphone' : 'Unmute microphone'}
        aria-pressed={micOn}
        title={micOn ? 'Mute mic' : 'Unmute mic'}
        tabIndex={open ? 0 : -1}
        onPointerDown={(e) => e.stopPropagation()}
        onClick={onMic}
        className={cn(
          buttonBase,
          'right-[6px] top-[38px] delay-75',
          micOn
            ? 'border-cyan-300/50 bg-gradient-to-br from-[#5b6cff] to-[#a35bff]'
            : 'border-white/20 bg-[#0d1230]/80 hover:bg-[#1a2150]/90',
          open ? 'pointer-events-auto translate-x-0 translate-y-0 scale-100 opacity-100' : '-translate-x-10 translate-y-8 scale-50 opacity-0',
        )}
      >
        {micOn ? <Mic className="size-5" aria-hidden="true" /> : <MicOff className="size-5" aria-hidden="true" />}
      </button>
    </div>
  )
}
