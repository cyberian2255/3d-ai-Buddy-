'use client'

import { cn } from '@/lib/utils'

type LiveCaptionProps = {
  text: string | null
  thinking: boolean
}

export function LiveCaption({ text, thinking }: LiveCaptionProps) {
  const visible = thinking || !!text
  return (
    <div
      aria-live="polite"
      className={cn(
        'pointer-events-none absolute bottom-full left-1/2 mb-1 flex max-w-[240px] -translate-x-1/2 items-center gap-2 rounded-2xl border border-white/10 bg-black/60 px-3 py-1.5 text-xs leading-snug text-white/90 backdrop-blur-md transition-all duration-200',
        visible ? 'translate-y-0 opacity-100' : 'translate-y-1 opacity-0',
      )}
    >
      {thinking && (
        <span className="flex gap-0.5" aria-hidden="true">
          <span className="size-1.5 animate-bounce rounded-full bg-cyan-300 [animation-delay:-0.3s]" />
          <span className="size-1.5 animate-bounce rounded-full bg-[#7f8cff] [animation-delay:-0.15s]" />
          <span className="size-1.5 animate-bounce rounded-full bg-[#a35bff]" />
        </span>
      )}
      <span className="line-clamp-2 w-max">{text ?? (thinking ? 'Thinking' : '')}</span>
    </div>
  )
}
