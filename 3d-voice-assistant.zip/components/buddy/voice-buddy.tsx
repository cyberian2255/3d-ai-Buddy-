'use client'

import { useEffect, useRef, useState, type KeyboardEvent, type PointerEvent } from 'react'
import { Settings } from 'lucide-react'
import { BuddyScene } from '@/lib/buddy/buddy-scene'
import { isRecognitionSupported, startRecognition } from '@/lib/buddy/recognition'
import { captureScreenFrame } from '@/lib/buddy/screen-capture'
import { initVoices, primeSpeech, speak } from '@/lib/buddy/speech'
import { LiveCaption } from './live-caption'
import { RadialRing } from './radial-ring'
import { SettingsPanel } from './settings-panel'

const W = 196
const H = 220
const SLEEP_AFTER_MS = 45_000
const KEY_STORAGE = 'buddy.openrouterKey'
const MODEL_STORAGE = 'buddy.model'

type Mode = 'idle' | 'listening' | 'thinking' | 'speaking'
type Action = 'IDLE' | 'JUMP' | 'LAUGH' | 'FACEPALM' | 'POINT'
type Point = { x: number; y: number }
type HistoryMessage = { role: 'user' | 'assistant'; content: string }
type Gesture = {
  startX: number
  startY: number
  originX: number
  originY: number
  dragging: boolean
  held: boolean
  timer: ReturnType<typeof setTimeout>
}

function clampPos(x: number, y: number): Point {
  const maxX = Math.max(4, window.innerWidth - W - 4)
  const maxY = Math.max(56, window.innerHeight - H - 4)
  return { x: Math.min(maxX, Math.max(4, x)), y: Math.min(maxY, Math.max(56, y)) }
}

export function VoiceBuddy() {
  const widgetRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const sceneRef = useRef<BuddyScene | null>(null)
  const pos = useRef<Point>({ x: 0, y: 0 })
  const walkTarget = useRef<(Point & { onArrive?: () => void }) | null>(null)
  const gesture = useRef<Gesture | null>(null)
  const recRef = useRef<ReturnType<typeof startRecognition>>(null)
  const stopSpeechRef = useRef<(() => void) | null>(null)
  const historyRef = useRef<HistoryMessage[]>([])
  const lastActivity = useRef(0)
  const nextWanderAt = useRef(0)
  const captionTimer = useRef<ReturnType<typeof setTimeout>>(undefined)
  const ringTimer = useRef<ReturnType<typeof setTimeout>>(undefined)

  const modeRef = useRef<Mode>('idle')
  const micOnRef = useRef(false)
  const sleepingRef = useRef(false)
  const keyRef = useRef('')
  const modelRef = useRef('')

  const [mode, setModeState] = useState<Mode>('idle')
  const [micOn, setMicOnState] = useState(false)
  const [ready, setReady] = useState(false)
  const [caption, setCaption] = useState<string | null>(null)
  const [ringOpen, setRingOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [savedKey, setSavedKey] = useState('')
  const [savedModel, setSavedModel] = useState('')
  const [marker, setMarker] = useState<(Point & { id: number }) | null>(null)

  function applyPos() {
    const el = widgetRef.current
    if (el) el.style.transform = `translate3d(${pos.current.x}px, ${pos.current.y}px, 0)`
  }

  function setMode(next: Mode) {
    modeRef.current = next
    setModeState(next)
    const scene = sceneRef.current
    if (!scene) return
    scene.setBase(next === 'listening' ? 'listening' : next === 'thinking' ? 'thinking' : 'idle')
    scene.setSpeaking(next === 'speaking')
  }

  function setMicOn(on: boolean) {
    micOnRef.current = on
    setMicOnState(on)
  }

  function flash(text: string, ms = 2600) {
    clearTimeout(captionTimer.current)
    setCaption(text)
    captionTimer.current = setTimeout(() => setCaption(null), ms)
  }

  function showRing() {
    clearTimeout(ringTimer.current)
    setRingOpen(true)
    ringTimer.current = setTimeout(() => setRingOpen(false), 5000)
  }

  function wake() {
    lastActivity.current = Date.now()
    if (!sleepingRef.current) return
    sleepingRef.current = false
    sceneRef.current?.setSleeping(false)
    sceneRef.current?.play('jump')
  }

  function goToSleep() {
    sleepingRef.current = true
    walkTarget.current = null
    sceneRef.current?.setWalking(false)
    sceneRef.current?.setSleeping(true)
    setRingOpen(false)
  }

  function walkTo(x: number, y: number, onArrive?: () => void) {
    walkTarget.current = { ...clampPos(x, y), onArrive }
  }

  function walkToPoint(pt: Point) {
    const px = pt.x * window.innerWidth
    const py = pt.y * window.innerHeight
    const id = Date.now()
    setMarker({ x: px, y: py, id })
    setTimeout(() => setMarker((m) => (m?.id === id ? null : m)), 6000)
    const pointLeft = px < window.innerWidth / 2
    const handReach = 52
    const x = pointLeft ? px + handReach - W / 2 : px - handReach - W / 2
    walkTo(x, py - H / 2, () => sceneRef.current?.play('point', pointLeft ? -1 : 1))
  }

  function onTick(dt: number) {
    const target = walkTarget.current
    const scene = sceneRef.current
    if (!target || !scene || gesture.current?.dragging) return
    const dx = target.x - pos.current.x
    const dy = target.y - pos.current.y
    const dist = Math.hypot(dx, dy)
    const step = 150 * dt
    if (dist <= step) {
      pos.current = { x: target.x, y: target.y }
      walkTarget.current = null
      scene.setWalking(false)
      target.onArrive?.()
    } else {
      pos.current = { x: pos.current.x + (dx / dist) * step, y: pos.current.y + (dy / dist) * step }
      scene.setWalking(true, Math.abs(dx) > Math.abs(dy) * 0.5 ? Math.sign(dx) : 0)
    }
    applyPos()
  }

  function say(text: string, action: Action = 'IDLE', point: Point | null = null) {
    recRef.current?.abort()
    recRef.current = null
    setMode('speaking')
    setCaption(null)
    const scene = sceneRef.current
    if (action === 'JUMP') scene?.play('jump')
    else if (action === 'LAUGH') scene?.play('laugh')
    else if (action === 'FACEPALM') scene?.play('facepalm')
    else if (action === 'POINT' && point) walkToPoint(point)

    stopSpeechRef.current = speak(text, {
      onBoundary: () => sceneRef.current?.pulseSpeech(),
      onEnd: () => {
        stopSpeechRef.current = null
        if (modeRef.current !== 'speaking') return
        lastActivity.current = Date.now()
        if (micOnRef.current) listen()
        else setMode('idle')
      },
    })
  }

  function interruptSpeech() {
    if (modeRef.current === 'speaking') setMode('idle')
    stopSpeechRef.current?.()
    stopSpeechRef.current = null
  }

  async function ask(text: string, image?: string) {
    recRef.current?.abort()
    recRef.current = null
    setMode('thinking')
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-openrouter-key': keyRef.current },
        body: JSON.stringify({ text, image, history: historyRef.current, model: modelRef.current || undefined }),
      })
      const data = await res.json()
      setCaption(null)
      if (!res.ok) {
        if (data.error === 'invalid_key' || data.error === 'missing_key') {
          setSettingsOpen(true)
          say('That key just bounced, chief. Give me a real one and I’ll stop judging you.', 'FACEPALM')
        } else if (data.error === 'no_credits') {
          say('We’re out of credits, partner. Even sidekicks need snacks.', 'FACEPALM')
        } else if (data.error === 'rate_limited') {
          say('The free models are slammed right now, chief. Give me a sec and try again.', 'FACEPALM')
        } else {
          say('My brain is buffering, partner. Hit me again in a moment.', 'FACEPALM')
        }
        return
      }
      historyRef.current = [
        ...historyRef.current,
        { role: 'user' as const, content: image ? `${text} [shared a screenshot]` : text },
        { role: 'assistant' as const, content: data.text as string },
      ].slice(-10)
      say(data.text, data.action, data.point)
    } catch {
      setCaption(null)
      say('Lost the connection, partner. Blame the Wi-Fi, not me.', 'FACEPALM')
    }
  }

  function listen() {
    recRef.current?.abort()
    setMode('listening')
    const rec = startRecognition({
      onSpeech: wake,
      onInterim: (t) => {
        wake()
        clearTimeout(captionTimer.current)
        setCaption(t)
      },
      onFinal: (t) => {
        wake()
        clearTimeout(captionTimer.current)
        setCaption(t)
        void ask(t)
      },
      onError: (err) => {
        if (err === 'not-allowed' || err === 'service-not-allowed' || err === 'audio-capture') {
          setMicOn(false)
          say('I can’t hear you, chief. Let me use the microphone first.', 'FACEPALM')
        }
      },
      onEnd: () => {
        recRef.current = null
        if (modeRef.current !== 'listening') return
        if (!micOnRef.current) {
          setMode('idle')
          return
        }
        setTimeout(() => {
          if (micOnRef.current && modeRef.current === 'listening' && !recRef.current) listen()
        }, 250)
      },
    })
    recRef.current = rec
    if (!rec) {
      setMicOn(false)
      setMode('idle')
    }
  }

  // The server may hold OPENROUTER_API_KEY; it replies `missing_key` if neither side has one.
  function requireKey() {
    return true
  }

  function startListening() {
    if (!isRecognitionSupported()) {
      say('This browser can’t hear me, chief. Try Chrome or Edge.', 'FACEPALM')
      return
    }
    if (!requireKey()) return
    setMicOn(true)
    listen()
  }

  function stopListening() {
    setMicOn(false)
    recRef.current?.abort()
    recRef.current = null
    if (modeRef.current === 'listening') setMode('idle')
    setCaption(null)
  }

  function handleTap() {
    primeSpeech()
    wake()
    showRing()
    if (modeRef.current === 'speaking') {
      interruptSpeech()
      startListening()
    } else if (modeRef.current === 'thinking') {
      flash('Hold on, still cooking', 1500)
    } else if (micOnRef.current) {
      stopListening()
    } else {
      startListening()
    }
  }

  function handleMicToggle() {
    primeSpeech()
    wake()
    showRing()
    if (micOnRef.current) {
      stopListening()
      flash('Mic muted', 1200)
    } else {
      interruptSpeech()
      startListening()
    }
  }

  async function handleVision() {
    primeSpeech()
    wake()
    setRingOpen(false)
    interruptSpeech()
    recRef.current?.abort()
    recRef.current = null
    let image: string
    try {
      const capture = captureScreenFrame()
      setMode('thinking')
      setCaption('Pick a screen to share')
      image = await capture
    } catch (err) {
      setCaption(null)
      const name = err instanceof DOMException ? err.name : ''
      if (name === 'NotAllowedError' || name === 'AbortError') say('Fine, keep your secrets, chief.', 'FACEPALM')
      else say('Screen sharing isn’t available here, partner. Try a desktop browser.', 'FACEPALM')
      return
    }
    setCaption('Scanning your screen')
    void ask(
      'Take a look at my screen and tell me what you see. If there is a bug, error, or something off, point right at it.',
      image,
    )
  }

  function handleSaveSettings(key: string, model: string) {
    localStorage.setItem(KEY_STORAGE, key)
    if (model) localStorage.setItem(MODEL_STORAGE, model)
    else localStorage.removeItem(MODEL_STORAGE)
    keyRef.current = key
    modelRef.current = model
    setSavedKey(key)
    setSavedModel(model)
    setSettingsOpen(false)
    primeSpeech()
    wake()
    say('Key locked in. Let’s go cause some trouble, partner.', 'JUMP')
  }

  function onPointerDown(e: PointerEvent<HTMLDivElement>) {
    if (e.button !== 0) return
    e.currentTarget.setPointerCapture(e.pointerId)
    const g: Gesture = {
      startX: e.clientX,
      startY: e.clientY,
      originX: pos.current.x,
      originY: pos.current.y,
      dragging: false,
      held: false,
      timer: setTimeout(() => {
        g.held = true
        wake()
        showRing()
        navigator.vibrate?.(15)
      }, 450),
    }
    gesture.current = g
  }

  function onPointerMove(e: PointerEvent<HTMLDivElement>) {
    const g = gesture.current
    if (!g) return
    const dx = e.clientX - g.startX
    const dy = e.clientY - g.startY
    if (!g.dragging && Math.hypot(dx, dy) > 8) {
      g.dragging = true
      clearTimeout(g.timer)
      walkTarget.current = null
      sceneRef.current?.setWalking(false)
      sceneRef.current?.setGrabbed(true)
      wake()
    }
    if (g.dragging) {
      pos.current = clampPos(g.originX + dx, g.originY + dy)
      applyPos()
    }
  }

  function endGesture(allowTap: boolean) {
    const g = gesture.current
    if (!g) return
    clearTimeout(g.timer)
    gesture.current = null
    if (g.dragging) {
      sceneRef.current?.setGrabbed(false)
      lastActivity.current = Date.now()
    } else if (allowTap && !g.held) {
      handleTap()
    }
  }

  function onKeyDown(e: KeyboardEvent<HTMLDivElement>) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      handleTap()
    }
  }

  useEffect(() => {
    initVoices()
    const storedKey = localStorage.getItem(KEY_STORAGE) ?? ''
    const storedModel = localStorage.getItem(MODEL_STORAGE) ?? ''
    keyRef.current = storedKey
    modelRef.current = storedModel
    setSavedKey(storedKey)
    setSavedModel(storedModel)

    const canvas = canvasRef.current
    if (!canvas) return
    const scene = new BuddyScene(canvas)
    sceneRef.current = scene
    scene.onTick = onTick

    pos.current = clampPos(window.innerWidth - W - 12, window.innerHeight - H - 24)
    applyPos()
    setReady(true)
    lastActivity.current = Date.now()
    nextWanderAt.current = Date.now() + 15_000
    flash('Tap me to talk', 4000)

    const onResize = () => {
      pos.current = clampPos(pos.current.x, pos.current.y)
      applyPos()
      scene.resize()
    }
    window.addEventListener('resize', onResize)

    const interval = setInterval(() => {
      const now = Date.now()
      const m = modeRef.current
      const idleish = m === 'idle' || m === 'listening'
      if (!sleepingRef.current && idleish && !gesture.current && now - lastActivity.current > SLEEP_AFTER_MS) {
        goToSleep()
        return
      }
      if (!sleepingRef.current && m === 'idle' && !walkTarget.current && !gesture.current && now > nextWanderAt.current) {
        nextWanderAt.current = now + 20_000 + Math.random() * 15_000
        walkTo(pos.current.x + (Math.random() - 0.5) * 280, pos.current.y + (Math.random() - 0.5) * 120)
      }
    }, 1000)

    return () => {
      window.removeEventListener('resize', onResize)
      clearInterval(interval)
      clearTimeout(captionTimer.current)
      clearTimeout(ringTimer.current)
      recRef.current?.abort()
      window.speechSynthesis?.cancel()
      scene.dispose()
      sceneRef.current = null
    }
    // Mount-only: all handlers read mutable refs, so the initial closures stay correct.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <main>
      <h1 className="sr-only">Floating voice buddy</h1>

      <div
        ref={widgetRef}
        className="fixed left-0 top-0 z-50 select-none transition-opacity duration-500"
        style={{ width: W, height: H, opacity: ready ? 1 : 0 }}
      >
        <LiveCaption text={caption} thinking={mode === 'thinking'} />

        <div
          role="button"
          tabIndex={0}
          aria-label={micOn ? 'Voice buddy, listening. Tap to stop.' : 'Voice buddy. Tap to talk, hold for actions.'}
          aria-pressed={micOn}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={() => endGesture(true)}
          onPointerCancel={() => endGesture(false)}
          onKeyDown={onKeyDown}
          onContextMenu={(e) => e.preventDefault()}
          className="absolute inset-0 cursor-pointer touch-none rounded-[48px] outline-none [-webkit-tap-highlight-color:transparent] focus-visible:ring-2 focus-visible:ring-cyan-300/70"
        >
          <canvas ref={canvasRef} className="block h-full w-full" />
        </div>

        <RadialRing
          open={ringOpen}
          micOn={micOn}
          busy={mode === 'thinking'}
          onVision={handleVision}
          onMic={handleMicToggle}
        />

        <button
          type="button"
          aria-label="Open buddy settings"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={() => {
            wake()
            setSettingsOpen(true)
          }}
          className="absolute bottom-3 right-3 flex size-8 items-center justify-center rounded-full border border-white/10 bg-black/40 text-white/70 backdrop-blur-md transition-colors hover:bg-black/60 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
        >
          <Settings className="size-4" aria-hidden="true" />
        </button>
      </div>

      {marker && (
        <span
          key={marker.id}
          aria-hidden="true"
          className="pointer-events-none fixed z-40 size-10 -translate-x-1/2 -translate-y-1/2"
          style={{ left: marker.x, top: marker.y }}
        >
          <span className="absolute inset-0 animate-ping rounded-full border-2 border-cyan-300" />
          <span className="absolute inset-3 rounded-full bg-cyan-300/80 shadow-[0_0_20px_rgba(127,231,255,0.9)]" />
        </span>
      )}

      {settingsOpen && (
        <SettingsPanel
          initialKey={savedKey}
          initialModel={savedModel}
          onSave={handleSaveSettings}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </main>
  )
}
