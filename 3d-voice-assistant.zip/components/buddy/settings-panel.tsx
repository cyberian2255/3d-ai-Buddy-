'use client'

import { useState, type FormEvent } from 'react'
import { X } from 'lucide-react'

type SettingsPanelProps = {
  initialKey: string
  initialModel: string
  onSave: (key: string, model: string) => void
  onClose: () => void
}

export function SettingsPanel({ initialKey, initialModel, onSave, onClose }: SettingsPanelProps) {
  const [key, setKey] = useState(initialKey)
  const [model, setModel] = useState(initialModel)
  const [error, setError] = useState<string | null>(null)

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    const trimmed = key.trim()
    if (!/^sk-or-[\w-]{10,}$/.test(trimmed)) {
      setError('That doesn’t look like an OpenRouter key (sk-or-v1-…).')
      return
    }
    const trimmedModel = model.trim()
    if (trimmedModel && !/^[\w.-]+\/[\w.:-]+$/.test(trimmedModel)) {
      setError('Model should look like provider/model-name.')
      return
    }
    onSave(trimmed, trimmedModel)
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="buddy-settings-title"
      onKeyDown={(e) => e.key === 'Escape' && onClose()}
      className="fixed left-1/2 top-1/2 z-[60] w-[min(92vw,340px)] -translate-x-1/2 -translate-y-1/2 rounded-3xl border border-white/10 bg-[#0b0e1f]/90 p-5 text-white shadow-[0_20px_80px_-20px_rgba(91,108,255,0.6)] backdrop-blur-xl animate-in fade-in zoom-in-95"
    >
      <div className="mb-4 flex items-center justify-between">
        <h2 id="buddy-settings-title" className="text-sm font-semibold tracking-wide">
          Buddy settings
        </h2>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close settings"
          className="flex size-8 items-center justify-center rounded-full text-white/60 hover:bg-white/10 hover:text-white"
        >
          <X className="size-4" aria-hidden="true" />
        </button>
      </div>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        <label className="flex flex-col gap-1.5">
          <span className="text-xs text-white/60">OpenRouter API key</span>
          <input
            type="password"
            autoFocus
            autoComplete="off"
            spellCheck={false}
            value={key}
            onChange={(e) => {
              setKey(e.target.value)
              setError(null)
            }}
            placeholder="sk-or-v1-..."
            className="h-11 rounded-xl border border-white/10 bg-white/5 px-3 font-mono text-sm outline-none placeholder:text-white/30 focus:border-[#5b6cff] focus:ring-2 focus:ring-[#5b6cff]/40"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-xs text-white/60">Preferred model (optional)</span>
          <input
            type="text"
            autoComplete="off"
            spellCheck={false}
            value={model}
            onChange={(e) => {
              setModel(e.target.value)
              setError(null)
            }}
            placeholder="google/gemma-4-31b-it:free"
            className="h-11 rounded-xl border border-white/10 bg-white/5 px-3 font-mono text-sm outline-none placeholder:text-white/30 focus:border-[#5b6cff] focus:ring-2 focus:ring-[#5b6cff]/40"
          />
        </label>
        {error && (
          <p role="alert" className="text-xs text-rose-300">
            {error}
          </p>
        )}
        <p className="text-[11px] leading-relaxed text-white/45">
          Saved only in this browser. Falls back to meta-llama/llama-3.3-70b-instruct:free. Get a key at{' '}
          <a href="https://openrouter.ai/keys" target="_blank" rel="noreferrer" className="text-cyan-300 underline-offset-2 hover:underline">
            openrouter.ai/keys
          </a>
          .
        </p>
        <button
          type="submit"
          className="mt-1 h-11 rounded-xl bg-gradient-to-r from-[#5b6cff] to-[#a35bff] text-sm font-semibold shadow-[0_8px_30px_-8px_rgba(163,91,255,0.8)] transition-opacity hover:opacity-90"
        >
          Save key
        </button>
      </form>
    </div>
  )
}
