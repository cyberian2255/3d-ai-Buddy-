# 3D Voice Assistant

Next.js app with a 3D voice buddy. Chat goes through `/api/chat`, which uses OpenRouter.

## Run locally
```bash
cp .env.example .env.local   # add your OPENROUTER_API_KEY
pnpm install
pnpm dev
```

## Deploy
The app has a server API route, so it can't run on GitHub Pages. Import the repo on
Vercel and add `OPENROUTER_API_KEY` as an environment variable.
